function open_profile_photo()
{
	document.getElementById("profile_pic_open_box").style.display='block';
}
function close_profile_photo()
{
	document.getElementById("profile_pic_open_box").style.display='none';
}
function open_cover_photo()
{
	document.getElementById("cover_pic_open_box").style.display='block';
}
function close_cover_photo()
{
	document.getElementById("cover_pic_open_box").style.display='none';
}