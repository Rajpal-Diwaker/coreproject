<?php include_once(__DIR__.'/../../../includes/template/header_public.inc'); ?>
<link href="<?php echo HOME_URL ?>extensions/user/user.css" media="all" rel="stylesheet" type="text/css" />
<script type='text/javascript' src="<?php echo HOME_URL ?>extensions/user/user.js" ></script>
<?php require_once __DIR__.'/../template/user_login_template.php' ?>
<?php include_template('footer.inc') ?>
