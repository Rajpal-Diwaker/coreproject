<html>
<head>
</head>
<body>

	<!-- erorr Designing -->
<div style="display:none; z-index:2;" id="error_design_format"> 

<!-- erorr background -->
<div style="position:fixed;left:30.4%;top:53.7%; height:6%; width:34.2%;  background:#FFEBE8; z-index:3; ">   </div>


<!-- erorr boder -->
<div style="position:fixed;left:30.4%; top:53.7%; height:1; width:34.2%; background-color:#DD3C10; z-index:3; "> </div>
<div style="position:fixed;left:30.3%; top:53.7%; height:6.1%; width:0.08%; background-color:#DD3C10; z-index:3; "> </div>
<div style="position:fixed;left:30.3%; top:59.7%; height:1; width:34.3%; background-color:#DD3C10; z-index:3; "> </div>
<div style="position:fixed;left:64.6%; top:53.7%; height:6.1%; width:0.05%; background-color:#DD3C10; z-index:3;"> </div>

</div>

<div style="position:fixed; left:40%; top:55.5%; display:none; z-index:4;" id="first_select"> Please first select Image file. </div>

<div style="position:fixed;left:32%; top:54.2%; font-size:14px; display:none; z-index:4;" id="not_valid_img">  Unable to process this photo. Please check your photo's format and try again.  <br>
We support these photo formats: JPG, GIF, and PNG.  </div>

</body>
</html>
